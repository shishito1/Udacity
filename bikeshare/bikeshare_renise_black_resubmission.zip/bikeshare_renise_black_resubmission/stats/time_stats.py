import time

"""Display statistics on the most frequent times of travel."""
def get_time_stats(df):
    print('\nCalculating The Most Frequent Times of Travel...\n')
    start_time = time.time()

    print('Most common month: ', df['month'].mode()[0])

    print('Most common day of the week: ', df['day_of_week'].mode()[0])

    start_hour = df['Start Time'].dt.hour
    print('Most common start hour: ', start_hour.mode()[0])

    duration = time.time() - start_time
    print("\n\nThis took {} seconds.".format(duration))
    print('-'*40)
    