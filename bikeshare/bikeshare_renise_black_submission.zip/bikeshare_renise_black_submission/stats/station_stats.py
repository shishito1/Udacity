import time

def get_station_stats(df):
    """Displays statistics on the most popular stations and trip."""

    print('\nCalculating The Most Popular Stations and Trip...\n')
    start_time = time.time()

    # TO DO: display most commonly used start station
    print('Most common start station: ', df['Start Station'].mode()[0])

    # TO DO: display most commonly used end station
    print('Most commonly used end station: ', df['End Station'].mode()[0])

    # TO DO: display most frequent combination of start station and end station trip
    print('\n')
    frequent_start_end_station = df[['Start Station', 'End Station']].mode(axis=0)
    print('Most frequest start and end station combination:')
    for station in frequent_start_end_station:
        print(f"{station}: {frequent_start_end_station[station].to_string(index=False)}")

    print("\n\nThis took {} seconds.".format(time.time() - start_time))
    print('-'*40)
    