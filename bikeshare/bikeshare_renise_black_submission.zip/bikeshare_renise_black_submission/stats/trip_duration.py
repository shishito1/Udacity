import time

def get_trip_duration_stats(df):
    """Displays statistics on the total and average trip duration."""
    
    print('\nCalculating Trip Duration...\n')
    start_time = time.time()

    # TO DO: display total travel time
    print('Total travel time: ', df['Trip Duration'].sum())

    # TO DO: display mean travel time
    print('\nAverage travel time: ', df['Trip Duration'].mean())

    # Longest travel time
    print('\nLongest travel time: ', df['Trip Duration'].max())    

    print("\n\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)
    