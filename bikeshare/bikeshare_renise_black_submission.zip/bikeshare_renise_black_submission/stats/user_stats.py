import time

def get_user_stats(df, city):
    """Displays statistics on bikeshare users."""

    print('\nCalculating User Stats...\n')
    start_time = time.time()

    # TO DO: Display counts of user types
    user_type_count = df['User Type'].value_counts().astype(int).apply('{:,d}'.format)
    print('Count by user type:')
    print(f'{user_type_count.to_string(header=False)}')

    # TO DO: Display counts of gender
    print('\n')
    if city.title() != 'Washington':
        count_by_gender = df['Gender'].value_counts().astype(int).apply('{:,d}'.format)
        print('Count by gender:')
        print(f'{count_by_gender.to_string(header=False)}')
        

    # TO DO: Display earliest, most recent, and most common year of birth
    print('\n')
    if city.title() != 'Washington': 
        print('Earliest birth year: ', df['Birth Year'].min())
        print('Most recent birth year: ', df['Birth Year'].max())
        print('Most common birth year: ', df['Birth Year'].mode()[0])
        
        # Display subscribers under 30
        print('\n')
        number_under_thirty = len(df[df['Birth Year'] < 1994])
        print(f'Number of subscribers under 30: {number_under_thirty:,}')

        # Display subscribers over 30
        number_over_thirty = len(df[df['Birth Year'] >= 1994])
        print(f'Number of subscribers over 30: {number_over_thirty:,}')

    print("\n\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)
    