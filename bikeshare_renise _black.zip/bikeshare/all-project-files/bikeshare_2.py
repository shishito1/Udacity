import pandas as pd
import stats.time_stats as time_stats
import stats.station_stats as station_stats
import stats.trip_duration as trip_duration
import stats.user_stats as user_stats
import dt_time.filter_by_date as filter_by_date

CITY_DATA = { 
    'chicago': 'chicago.csv',
    'new york city': 'new_york_city.csv',
    'washington': 'washington.csv' 
    }
    
def view_more_lines_decision(df):
    """View raw data 5 lines at a time."""
    starting_number_of_lines = 5
    print(df.head(starting_number_of_lines))
    view_more_lines = input("\n Would you like to view more lines? Enter yes or no: \n")

    while view_more_lines.lower() == 'yes':
        starting_number_of_lines += 5

        if starting_number_of_lines >= len(df):
            break

        print(df.head(starting_number_of_lines))
        view_more_lines = input("\n Would you like to view more lines? Enter yes or no: \n")

    print('-'*40)

def get_filters():
    """
    Asks user to specify a city, month, and day to analyze.

    Returns:
        city: name of the city to analyze
        month: name of the month to filter by, or "all" to apply no month filter
        day: name of the day of week to filter by, or "all" to apply no day filter
    """
    print('Hello! Let\'s explore some US bikeshare data!')
    # TO DO: get user input for city (chicago, new york city, washington). HINT: Use a while loop to handle invalid inputs
    city = input("Enter a city (chicago, new york city or washington): ").lower()
    
    while city not in ['chicago', 'new york city', 'washington']:
        city = input('Input not valid. City must be chicago, new york city or washingto: .').lower()

    # TO DO: get user input for month (all, january, february, ... , june)
    month = input("Enter a month (all, january, february, ...): ").lower()

    # TO DO: get user input for day of week (all, monday, tuesday, ... sunday)
    day = input ("Enter day of the week (all, monday, tuesday, ..., sunday): ").lower()

    print('-'*40)
    return city, month, day

def load_data(city, month, day):
    """
    Loads data for the specified city and filters by month and day if applicable.

    Args:
        city: the city to analyze
        month: the month to filter by, or "all" to apply no month filter
        day: the day of week to filter by, or "all" to apply no day filter
    Returns:
        df - Pandas DataFrame containing city data filtered by month and day
    """
    # load data file into a dataframe
    df = pd.read_csv(CITY_DATA[city])

    # convert the Start Time column to datetime
    df['Start Time'] = pd.to_datetime(df['Start Time'])
    # extract month and day of week from Start Time to create new columns
    df['month'] = df['Start Time'].dt.month
    df['day_of_week'] = df['Start Time'].dt.day_name()
    
    # change birth year to int
    df['Birth Year'] = df['Birth Year'].astype('Int64')

    filter_by_date.filter_by_month(df, month)
    filter_by_date.filter_by_day(df, day)

    return df

def main():
    while True:
        city, month, day = get_filters()
        df = load_data(city, month, day)

        view_more_lines_decision(df)

        print('-'*40)
        time_stats.get_time_stats(df)
        station_stats.get_station_stats(df)
        trip_duration.get_trip_duration_stats(df)
        user_stats.get_user_stats(df, city)

        restart = input('\nWould you like to restart? Enter yes or no.\n')
        if restart.lower() != 'yes':
            break


if __name__ == "__main__":
	main()