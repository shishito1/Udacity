import time

def get_station_stats(df):
    """Displays statistics on the most popular stations and trip."""

    print('\nCalculating The Most Popular Stations and Trip...\n')
    start_time = time.time()

    # TO DO: display most commonly used start station
    print('Most common start station:\n', df['Start Station'].mode())

    # TO DO: display most commonly used end station
    print('\n')
    print('Most commonly used end station:\n', df['End Station'].mode())

    # TO DO: display most frequent combination of start station and end station trip
    print('\n')
    most_frequent_start_end_station = df[['Start Station', 'End Station']].mode(axis=0)
    print('Most frequest start and end station combination:\n', most_frequent_start_end_station)

    print("\nThis took {} seconds.".format(time.time() - start_time))
    print('-'*40)
    