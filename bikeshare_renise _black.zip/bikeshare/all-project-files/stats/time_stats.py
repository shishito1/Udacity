import time

def get_time_stats(df):
    """Displays statistics on the most frequent times of travel."""

    print('\nCalculating The Most Frequent Times of Travel...\n')
    start_time = time.time()

    # TO DO: display the most common month
    print('Most common month: ', df['month'].mode())

    # TO DO: display the most common day of week
    print('Most common day of the week: ', df['day_of_week'].mode())

    # TO DO: display the most common start hour
    start_hour = df['Start Time'].dt.hour
    print(start_hour.mode())

    duration = time.time() - start_time
    print("\nThis took {} seconds.".format(duration))
    print('-'*40)
    