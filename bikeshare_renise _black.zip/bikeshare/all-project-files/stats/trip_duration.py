import time

def get_trip_duration_stats(df):
    """Displays statistics on the total and average trip duration."""
    
    print('\nCalculating Trip Duration...\n')
    start_time = time.time()

    # TO DO: display total travel time
    print('Total travel time: ', df['Trip Duration'].sum())

    # TO DO: display mean travel time
    print('\n')
    print('Average travel time: ', df['Trip Duration'].mean())

    # Longest travel time
    print('\n')
    print('Longest travel time: ', df['Trip Duration'].max())    

    print('\n')
    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)
    