import time

def get_user_stats(df, city):
    """Displays statistics on bikeshare users."""

    print('\nCalculating User Stats...\n')
    start_time = time.time()

    # TO DO: Display counts of user types
    user_type_count = df['User Type'].value_counts()
    print('Counts by user type: ', user_type_count)

    # TO DO: Display counts of gender
    print('\n')
    if city.title() == 'Washington':
        print('Gender data not for this %s.', city.title())
    else:
        count_by_gender = df['Gender'].value_counts()
        print('Counts by gender: ', count_by_gender)
        

    # TO DO: Display earliest, most recent, and most common year of birth
    print('\n')
    if city.title() == 'Washington':
        print('Birth year data not available for this %s.\n', city.title())
    else: 
        print('Earliest birth year: ', df['Birth Year'].min())
        print('Most recent birth year: ', df['Birth Year'].max())
        print('Most common year of birth: ', df['Birth Year'].mode())
        
        # Display subscribers under 30
        print('\n')
        number_under_thirty = len(df[df['Birth Year'] < 1994])
        print('Number of subscribers under 30: ', number_under_thirty)

        # Display subscribers over 30
        number_over_thirty = len(df[df['Birth Year'] >= 1994])
        print('Number of subscribers over 30: ', number_over_thirty)

    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)
    