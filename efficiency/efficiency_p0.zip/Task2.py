"""
Read file into texts and calls.
It's ok if you don't understand how to read files
"""
import csv
with open('texts.csv', 'r') as f:
    reader = csv.reader(f)
    texts = list(reader)

with open('calls.csv', 'r') as f:
    reader = csv.reader(f)
    calls = list(reader)

"""
TASK 2: Which telephone number spent the longest time on the phone
during the period? Don't forget that time spent answering a call is
also time spent on the phone.
Print a message:
"<telephone number> spent the longest time, <total time> seconds, on the phone during 
September 2016.".
"""
# Get a list of unique phone numbers.
unique_numbers = set()
for call in calls:
    unique_numbers.add(call[0])

# Create a dictionary with phone number as key.
duration_sums = dict()
for phone_number in unique_numbers:
    for call in calls:
        if call[2].startswith('11-'):
            if phone_number not in duration_sums:
                duration_sums[phone_number] = int(call[-1])
            else: 
                duration_sums[phone_number] += int(call[-1])

# Get the largest call duration by phone number.
longest_duration_key = max(duration_sums, key=lambda key: duration_sums[key])
print(f"{longest_duration_key} spent the longest time, {duration_sums[longest_duration_key]} seconds, on the phone during September 2016.")
